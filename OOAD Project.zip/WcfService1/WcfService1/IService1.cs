﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here
        [OperationContract]
        void AddUser(UserDetail user);

        [OperationContract]
        List<Roles> getroleList();

        [OperationContract]
        void addRole(Roles Role);

        [OperationContract]
        Roles getRoles(int index);


        [OperationContract]
        List<Goals> getgoalList();

        [OperationContract]
        void SaveRole(Roles Role, int index);

        [OperationContract]
        void DeleteRole(int idx);

        [OperationContract]

        void addGoal(Goals Goal);

        [OperationContract]
        void AddGoal(Goals GOAL, Roles ROLE);

        [OperationContract]
        Goals getGoal(int index);

        [OperationContract]
        void DeleteGoal(int n);

        [OperationContract]
        void addToDo(ToDo td);

        [OperationContract]
        List<ToDo> getToDolist();

        [OperationContract]
        void addReport(Reports r);

        [OperationContract]
        List<Reports> getReportlist();
        /*
        [OperationContract]
        bool userValidity(string UserName, string Password);
        */


    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
