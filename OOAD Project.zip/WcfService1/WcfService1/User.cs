﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class User
    {
        public static List<UserDetail> data = new List<UserDetail>();
        public static List<Roles> role = new List<Roles>();
        public static List<Goals> goal = new List<Goals>();
        public static List<ToDo> todo = new List<ToDo>();
        public static List<Reports> reports = new List<Reports>();

       
    }

}