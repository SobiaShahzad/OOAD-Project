﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class Roles
    {
        protected string roleName;
        protected string roleType;

        public string RoleName
        {
            get
            {
                return roleName;
            }

            set
            {
                roleName = value;
            }
        }

        public string RoleType
        {
            get
            {
                return roleType;
            }

            set
            {
                roleType = value;
            }
        }
    }
}