﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class Reports : ToDo 
    {
        public string rep;

        public string Rep
        {
            get
            {
                return rep;
            }

            set
            {
                rep = value;
            }
        }
    }
}