﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class Goals: Roles
    {

        protected string goalName;

        public string NameOfGoal
        {
            get
            {
                return goalName;
            }

            set
            {
                goalName = value;
            }
        }
    }
}