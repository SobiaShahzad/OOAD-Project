﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, `please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public void AddUser(UserDetail user)
        {
            User.data.Add(user);
        }

        public List<Roles> getroleList()
        {
            return User.role;
        }
        public void addRole(Roles Role)
        {
            // User is the list class
            User.role.Add(Role);
        }


        public Roles getRoles(int index)
        {
            return User.role[index];
        }

        public void SaveRole(Roles Role, int index)
        {
            User.role.RemoveAt(index);
            User.role.Insert(index,Role);
        }

         public void DeleteRole(int idx)
        {
            User.role.RemoveAt(idx);
        }
    

        /*
        public bool userVaidity(string UserName, string Password)
        {
            
            for(int i=0;i<UserDetail.count;++i)
            {
                if(UserDetail.UserName[i]==UserName && UserDetail.Password[i]==Password)
                {
                    return true;
                }
            }
            return false;
            
        }

    */


        public List<Goals> getgoalList()
        {
            return User.goal;
        }

       public void addGoal(Goals Goal)
        {
            User.goal.Add(Goal);
        }
       public void AddGoal(Goals GOAL, Roles ROLE)
        {
            User.goal.Add(GOAL);
            User.role.Add(ROLE);
        }
        public Goals getGoal(int index)
        {
            return User.goal[index];
        }
         public void DeleteGoal(int n)
        {
            User.goal.RemoveAt(n);
        }
        public void addToDo(ToDo td)
        {
            User.todo.Add(td);
        }
        public List<ToDo> getToDolist()
        {
            return User.todo;
        }
        public void addReport(Reports r)
        {
            User.reports.Add(r);
        }
        public List<Reports> getReportlist()
        {
            return User.reports;
        }
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
