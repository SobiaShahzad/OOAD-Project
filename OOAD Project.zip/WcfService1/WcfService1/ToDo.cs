﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class ToDo : Goals
    {
        protected string nameOfToDo;
      //  protected string date;

        public string NameOfToDo
        {
            get
            {
                return nameOfToDo;
            }

            set
            {
                nameOfToDo = value;
            }
        }
    }
}