﻿namespace WindowsFormsApplication2
{
    partial class ToDo_s
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportsbtnintodo = new System.Windows.Forms.Button();
            this.todobtnintodo = new System.Windows.Forms.Button();
            this.goalbtnintodo = new System.Windows.Forms.Button();
            this.rolebtnintodo = new System.Windows.Forms.Button();
            this.goallblintodo = new System.Windows.Forms.Label();
            this.goalcomboboxintodo = new System.Windows.Forms.ComboBox();
            this.rolenamelblntodo = new System.Windows.Forms.Label();
            this.roletypelblintodo = new System.Windows.Forms.Label();
            this.todolblintodo = new System.Windows.Forms.Label();
            this.todotasktxt = new System.Windows.Forms.TextBox();
            this.todogridview = new System.Windows.Forms.DataGridView();
            this.addbtnintodo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tododateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.clickheretogotoreportbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.todogridview)).BeginInit();
            this.SuspendLayout();
            // 
            // reportsbtnintodo
            // 
            this.reportsbtnintodo.Location = new System.Drawing.Point(41, 122);
            this.reportsbtnintodo.Name = "reportsbtnintodo";
            this.reportsbtnintodo.Size = new System.Drawing.Size(75, 23);
            this.reportsbtnintodo.TabIndex = 12;
            this.reportsbtnintodo.Text = "Reports";
            this.reportsbtnintodo.UseVisualStyleBackColor = true;
            // 
            // todobtnintodo
            // 
            this.todobtnintodo.BackColor = System.Drawing.Color.Aqua;
            this.todobtnintodo.Location = new System.Drawing.Point(41, 93);
            this.todobtnintodo.Name = "todobtnintodo";
            this.todobtnintodo.Size = new System.Drawing.Size(75, 23);
            this.todobtnintodo.TabIndex = 11;
            this.todobtnintodo.Text = "To Do\'s";
            this.todobtnintodo.UseVisualStyleBackColor = false;
            // 
            // goalbtnintodo
            // 
            this.goalbtnintodo.Location = new System.Drawing.Point(41, 64);
            this.goalbtnintodo.Name = "goalbtnintodo";
            this.goalbtnintodo.Size = new System.Drawing.Size(75, 23);
            this.goalbtnintodo.TabIndex = 10;
            this.goalbtnintodo.Text = "Goals";
            this.goalbtnintodo.UseVisualStyleBackColor = true;
            // 
            // rolebtnintodo
            // 
            this.rolebtnintodo.Location = new System.Drawing.Point(41, 35);
            this.rolebtnintodo.Name = "rolebtnintodo";
            this.rolebtnintodo.Size = new System.Drawing.Size(75, 24);
            this.rolebtnintodo.TabIndex = 9;
            this.rolebtnintodo.Text = "Roles";
            this.rolebtnintodo.UseVisualStyleBackColor = true;
            // 
            // goallblintodo
            // 
            this.goallblintodo.AutoSize = true;
            this.goallblintodo.Location = new System.Drawing.Point(202, 47);
            this.goallblintodo.Name = "goallblintodo";
            this.goallblintodo.Size = new System.Drawing.Size(29, 13);
            this.goallblintodo.TabIndex = 13;
            this.goallblintodo.Text = "Goal";
            // 
            // goalcomboboxintodo
            // 
            this.goalcomboboxintodo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.goalcomboboxintodo.FormattingEnabled = true;
            this.goalcomboboxintodo.Location = new System.Drawing.Point(263, 47);
            this.goalcomboboxintodo.Name = "goalcomboboxintodo";
            this.goalcomboboxintodo.Size = new System.Drawing.Size(121, 21);
            this.goalcomboboxintodo.TabIndex = 14;
            // 
            // rolenamelblntodo
            // 
            this.rolenamelblntodo.AutoSize = true;
            this.rolenamelblntodo.Location = new System.Drawing.Point(202, 86);
            this.rolenamelblntodo.Name = "rolenamelblntodo";
            this.rolenamelblntodo.Size = new System.Drawing.Size(60, 13);
            this.rolenamelblntodo.TabIndex = 15;
            this.rolenamelblntodo.Text = "Role Name";
            // 
            // roletypelblintodo
            // 
            this.roletypelblintodo.AutoSize = true;
            this.roletypelblintodo.Location = new System.Drawing.Point(202, 114);
            this.roletypelblintodo.Name = "roletypelblintodo";
            this.roletypelblintodo.Size = new System.Drawing.Size(31, 13);
            this.roletypelblintodo.TabIndex = 16;
            this.roletypelblintodo.Text = "Type";
            // 
            // todolblintodo
            // 
            this.todolblintodo.AutoSize = true;
            this.todolblintodo.Location = new System.Drawing.Point(202, 143);
            this.todolblintodo.Name = "todolblintodo";
            this.todolblintodo.Size = new System.Drawing.Size(44, 13);
            this.todolblintodo.TabIndex = 17;
            this.todolblintodo.Text = "To Do\'s";
            // 
            // todotasktxt
            // 
            this.todotasktxt.Location = new System.Drawing.Point(263, 143);
            this.todotasktxt.Name = "todotasktxt";
            this.todotasktxt.Size = new System.Drawing.Size(92, 20);
            this.todotasktxt.TabIndex = 19;
            // 
            // todogridview
            // 
            this.todogridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.todogridview.Location = new System.Drawing.Point(66, 181);
            this.todogridview.Name = "todogridview";
            this.todogridview.Size = new System.Drawing.Size(592, 215);
            this.todogridview.TabIndex = 22;
            // 
            // addbtnintodo
            // 
            this.addbtnintodo.Location = new System.Drawing.Point(605, 144);
            this.addbtnintodo.Name = "addbtnintodo";
            this.addbtnintodo.Size = new System.Drawing.Size(32, 23);
            this.addbtnintodo.TabIndex = 24;
            this.addbtnintodo.Text = "+";
            this.addbtnintodo.UseVisualStyleBackColor = true;
            this.addbtnintodo.Click += new System.EventHandler(this.addbtnintodo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(302, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "To Do\'s";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tododateTimePicker
            // 
            this.tododateTimePicker.CustomFormat = "";
            this.tododateTimePicker.Location = new System.Drawing.Point(387, 143);
            this.tododateTimePicker.Name = "tododateTimePicker";
            this.tododateTimePicker.Size = new System.Drawing.Size(189, 20);
            this.tododateTimePicker.TabIndex = 26;
            this.tododateTimePicker.ValueChanged += new System.EventHandler(this.tododateTimePicker_ValueChanged);
            // 
            // clickheretogotoreportbtn
            // 
            this.clickheretogotoreportbtn.Location = new System.Drawing.Point(583, 47);
            this.clickheretogotoreportbtn.Name = "clickheretogotoreportbtn";
            this.clickheretogotoreportbtn.Size = new System.Drawing.Size(126, 52);
            this.clickheretogotoreportbtn.TabIndex = 27;
            this.clickheretogotoreportbtn.Text = "Clicck here to go  to report";
            this.clickheretogotoreportbtn.UseVisualStyleBackColor = true;
            this.clickheretogotoreportbtn.Click += new System.EventHandler(this.clickheretogotoreportbtn_Click);
            // 
            // ToDo_s
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 408);
            this.Controls.Add(this.clickheretogotoreportbtn);
            this.Controls.Add(this.tododateTimePicker);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addbtnintodo);
            this.Controls.Add(this.todogridview);
            this.Controls.Add(this.todotasktxt);
            this.Controls.Add(this.todolblintodo);
            this.Controls.Add(this.roletypelblintodo);
            this.Controls.Add(this.rolenamelblntodo);
            this.Controls.Add(this.goalcomboboxintodo);
            this.Controls.Add(this.goallblintodo);
            this.Controls.Add(this.reportsbtnintodo);
            this.Controls.Add(this.todobtnintodo);
            this.Controls.Add(this.goalbtnintodo);
            this.Controls.Add(this.rolebtnintodo);
            this.Name = "ToDo_s";
            this.Text = "ToDo_s";
            this.Load += new System.EventHandler(this.ToDo_s_Load);
            ((System.ComponentModel.ISupportInitialize)(this.todogridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button reportsbtnintodo;
        private System.Windows.Forms.Button todobtnintodo;
        private System.Windows.Forms.Button goalbtnintodo;
        private System.Windows.Forms.Button rolebtnintodo;
        private System.Windows.Forms.Label goallblintodo;
        private System.Windows.Forms.ComboBox goalcomboboxintodo;
        private System.Windows.Forms.Label rolenamelblntodo;
        private System.Windows.Forms.Label roletypelblintodo;
        private System.Windows.Forms.Label todolblintodo;
        private System.Windows.Forms.DataGridView todogridview;
        private System.Windows.Forms.Button addbtnintodo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker tododateTimePicker;
        public System.Windows.Forms.TextBox todotasktxt;
        private System.Windows.Forms.Button clickheretogotoreportbtn;
    }
}