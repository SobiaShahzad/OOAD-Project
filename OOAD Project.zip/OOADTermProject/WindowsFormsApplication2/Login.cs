﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*
            if (txtUser.Text == (string)ServiceReference1.UserDetail.UserName && (string)ServiceReference1.UserDetail.Password)
            {
                MessageBox.Show("Login sucessfully");
                
            }
            else
            { 
                MessageBox.Show("Invalid username or password");
            }
         */   
        }

        private void txtUser_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtUser.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtUser, "Enter UserName");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtUser, null);
            }
        }

        private void txtUser_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtUser, null);
        }

        private void txtpswrd_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtpswrd.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtpswrd, "Enter UserName");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtpswrd, null);
            }
        }

        private void txtpswrd_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtpswrd, null);
        }

        private void btnclksignup_Click(object sender, EventArgs e)
        {

            SignUp signup = new SignUp();
            ActiveForm.Hide();
            signup.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {
            //dateandtimelbl.Text = dateTimePicker1.Value.ToString();
        }

        private void btnrole_Click(object sender, EventArgs e)
        {
            Roles rolelink = new Roles();
            rolelink.Show();
        }
    }
}
