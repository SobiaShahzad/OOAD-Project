﻿namespace WindowsFormsApplication2
{
    partial class Roles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportbtninroles = new System.Windows.Forms.Button();
            this.todobtninroles = new System.Windows.Forms.Button();
            this.goalbtninroles = new System.Windows.Forms.Button();
            this.rolebtninroles = new System.Windows.Forms.Button();
            this.rolenamelbl = new System.Windows.Forms.Label();
            this.rolenametxt = new System.Windows.Forms.TextBox();
            this.roletypecombobox = new System.Windows.Forms.ComboBox();
            this.roletypelbl = new System.Windows.Forms.Label();
            this.rolegridview = new System.Windows.Forms.DataGridView();
            this.addrolebtm = new System.Windows.Forms.Button();
            this.goalbtninrole = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.rolegridview)).BeginInit();
            this.SuspendLayout();
            // 
            // reportbtninroles
            // 
            this.reportbtninroles.Location = new System.Drawing.Point(32, 152);
            this.reportbtninroles.Name = "reportbtninroles";
            this.reportbtninroles.Size = new System.Drawing.Size(75, 23);
            this.reportbtninroles.TabIndex = 7;
            this.reportbtninroles.Text = "Report";
            this.reportbtninroles.UseVisualStyleBackColor = true;
            // 
            // todobtninroles
            // 
            this.todobtninroles.Location = new System.Drawing.Point(32, 123);
            this.todobtninroles.Name = "todobtninroles";
            this.todobtninroles.Size = new System.Drawing.Size(75, 23);
            this.todobtninroles.TabIndex = 6;
            this.todobtninroles.Text = "To Do\'s";
            this.todobtninroles.UseVisualStyleBackColor = true;
            // 
            // goalbtninroles
            // 
            this.goalbtninroles.BackColor = System.Drawing.SystemColors.Control;
            this.goalbtninroles.Location = new System.Drawing.Point(32, 94);
            this.goalbtninroles.Name = "goalbtninroles";
            this.goalbtninroles.Size = new System.Drawing.Size(75, 23);
            this.goalbtninroles.TabIndex = 5;
            this.goalbtninroles.Text = "Goals";
            this.goalbtninroles.UseVisualStyleBackColor = false;
            // 
            // rolebtninroles
            // 
            this.rolebtninroles.BackColor = System.Drawing.Color.Fuchsia;
            this.rolebtninroles.Location = new System.Drawing.Point(32, 65);
            this.rolebtninroles.Name = "rolebtninroles";
            this.rolebtninroles.Size = new System.Drawing.Size(75, 23);
            this.rolebtninroles.TabIndex = 4;
            this.rolebtninroles.Text = "Roles";
            this.rolebtninroles.UseVisualStyleBackColor = false;
            // 
            // rolenamelbl
            // 
            this.rolenamelbl.AutoSize = true;
            this.rolenamelbl.Location = new System.Drawing.Point(201, 75);
            this.rolenamelbl.Name = "rolenamelbl";
            this.rolenamelbl.Size = new System.Drawing.Size(60, 13);
            this.rolenamelbl.TabIndex = 8;
            this.rolenamelbl.Text = "Role Name";
            this.rolenamelbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // rolenametxt
            // 
            this.rolenametxt.Location = new System.Drawing.Point(289, 68);
            this.rolenametxt.Name = "rolenametxt";
            this.rolenametxt.Size = new System.Drawing.Size(100, 20);
            this.rolenametxt.TabIndex = 9;
            this.rolenametxt.Validating += new System.ComponentModel.CancelEventHandler(this.rolenametxt_Validating);
            // 
            // roletypecombobox
            // 
            this.roletypecombobox.FormattingEnabled = true;
            this.roletypecombobox.Items.AddRange(new object[] {
            "Teacher",
            "Social",
            "Work"});
            this.roletypecombobox.Location = new System.Drawing.Point(289, 115);
            this.roletypecombobox.Name = "roletypecombobox";
            this.roletypecombobox.Size = new System.Drawing.Size(121, 21);
            this.roletypecombobox.TabIndex = 10;
            // 
            // roletypelbl
            // 
            this.roletypelbl.AutoSize = true;
            this.roletypelbl.Location = new System.Drawing.Point(201, 123);
            this.roletypelbl.Name = "roletypelbl";
            this.roletypelbl.Size = new System.Drawing.Size(56, 13);
            this.roletypelbl.TabIndex = 11;
            this.roletypelbl.Text = "Role Type";
            // 
            // rolegridview
            // 
            this.rolegridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.rolegridview.Location = new System.Drawing.Point(32, 188);
            this.rolegridview.Name = "rolegridview";
            this.rolegridview.Size = new System.Drawing.Size(704, 172);
            this.rolegridview.TabIndex = 12;
            this.rolegridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.rolegridview_CellContentClick);
            // 
            // addrolebtm
            // 
            this.addrolebtm.Location = new System.Drawing.Point(257, 159);
            this.addrolebtm.Name = "addrolebtm";
            this.addrolebtm.Size = new System.Drawing.Size(75, 23);
            this.addrolebtm.TabIndex = 13;
            this.addrolebtm.Text = "Add Role";
            this.addrolebtm.UseVisualStyleBackColor = true;
            this.addrolebtm.Click += new System.EventHandler(this.addrolebtm_Click);
            // 
            // goalbtninrole
            // 
            this.goalbtninrole.Location = new System.Drawing.Point(560, 113);
            this.goalbtninrole.Name = "goalbtninrole";
            this.goalbtninrole.Size = new System.Drawing.Size(102, 46);
            this.goalbtninrole.TabIndex = 14;
            this.goalbtninrole.Text = "Click Here To go to Goal";
            this.goalbtninrole.UseVisualStyleBackColor = true;
            this.goalbtninrole.Click += new System.EventHandler(this.goalbtninrole_Click);
            // 
            // Roles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 372);
            this.Controls.Add(this.goalbtninrole);
            this.Controls.Add(this.addrolebtm);
            this.Controls.Add(this.rolegridview);
            this.Controls.Add(this.roletypelbl);
            this.Controls.Add(this.roletypecombobox);
            this.Controls.Add(this.rolenametxt);
            this.Controls.Add(this.rolenamelbl);
            this.Controls.Add(this.reportbtninroles);
            this.Controls.Add(this.todobtninroles);
            this.Controls.Add(this.goalbtninroles);
            this.Controls.Add(this.rolebtninroles);
            this.Name = "Roles";
            this.Text = "Roles";
            this.Load += new System.EventHandler(this.Roles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.rolegridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button reportbtninroles;
        private System.Windows.Forms.Button todobtninroles;
        private System.Windows.Forms.Button goalbtninroles;
        private System.Windows.Forms.Button rolebtninroles;
        private System.Windows.Forms.Label rolenamelbl;
        private System.Windows.Forms.TextBox rolenametxt;
        private System.Windows.Forms.ComboBox roletypecombobox;
        private System.Windows.Forms.Label roletypelbl;
        private System.Windows.Forms.DataGridView rolegridview;
        private System.Windows.Forms.Button addrolebtm;
        private System.Windows.Forms.Button goalbtninrole;
    }
}