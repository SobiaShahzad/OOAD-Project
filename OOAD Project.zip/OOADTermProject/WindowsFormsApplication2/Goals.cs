﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Goals : Form
    {
        private ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
        private ServiceReference1.Roles showgoal = new ServiceReference1.Roles();
        int index;
        public Goals()
        {
            InitializeComponent();
            
        }
        public Goals(ServiceReference1.Roles goal, int Index)
        {
            showgoal = goal;
            index = Index;
            InitializeComponent();

        }
        public void CombineDataMethod()
        {

            DataGridViewButtonColumn editbutton = new DataGridViewButtonColumn();
            editbutton.FlatStyle = FlatStyle.Popup;
            editbutton.HeaderText = "Edit";
            editbutton.Name = "Edit";
            editbutton.UseColumnTextForButtonValue = true;
            editbutton.Text = "Edit";
            editbutton.Width = 60;
            if (goalgridview.Columns.Contains(editbutton.Name = "Edit"))
            {

            }
            
            else
            {
                goalgridview.Columns.Add(editbutton);
            }

            DataGridViewButtonColumn Deletebutton = new DataGridViewButtonColumn();
            Deletebutton.FlatStyle = FlatStyle.Popup;
            Deletebutton.HeaderText = "Delete";
            Deletebutton.Name = "Delete";
            Deletebutton.UseColumnTextForButtonValue = true;
            Deletebutton.Text = "Delete";
            Deletebutton.Width = 60;
            if (goalgridview.Columns.Contains(editbutton.Name = "Delete"))
            {

            }
             
            else
            {
                goalgridview.Columns.Add(Deletebutton);
            }

            DataGridViewButtonColumn AddGoalbutton = new DataGridViewButtonColumn();
            AddGoalbutton.FlatStyle = FlatStyle.Popup;
            AddGoalbutton.HeaderText = "Delete";
            AddGoalbutton.Name = "Delete";
            AddGoalbutton.UseColumnTextForButtonValue = true;
            AddGoalbutton.Text = "Delete";
            AddGoalbutton.Width = 60;
            if (goalgridview.Columns.Contains(editbutton.Name = "Delete"))
            {

            }
              
            else
            {
                goalgridview.Columns.Add(AddGoalbutton);
            }
        }
        private void Goals_Load(object sender, EventArgs e)
        {
            rolenametxtingoal.Text = showgoal.RoleName;
            rolenametxtingoal.Text = showgoal.RoleType;
            Datashow();
        }

        public void Datashow()
        {
            ServiceReference1.Service1Client myclient = new ServiceReference1.Service1Client();
            BindingSource bds = new BindingSource();
            bds.DataSource = myclient.getgoalList();
            goalgridview.DataSource = bds;
          
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

                
                //goals = Server.getRole(INDEX);
                //EditGoals edit = new EditGoals(goals, INDEX);
                //edit.Show();
                // MessageBox.Show("ajsdh");

            

        }

        private void addgoalbtn_Click(object sender, EventArgs e)
        {

            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.Goals g = new ServiceReference1.Goals();
            g.NameOfGoal = goaltxtingoal.Text;
            g.RoleName = rolenametxtingoal.Text;
            g.RoleType = rolenametxtingoal.Text;
            server.addGoal(g);
            MessageBox.Show("Goal added successfully");
            Datashow();
            
        }

        private void todobtningoal_Click(object sender, EventArgs e)
        {
            ToDo_s tt = new ToDo_s();
            this.Close();
            tt.Show();
        }
    }
}
