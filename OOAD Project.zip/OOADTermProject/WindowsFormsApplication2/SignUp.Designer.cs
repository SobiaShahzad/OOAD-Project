﻿namespace WindowsFormsApplication2
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnSignup = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpasswrd = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnclklogin = new System.Windows.Forms.Button();
            this.btnroleinsignup = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnSignup
            // 
            this.BtnSignup.BackColor = System.Drawing.Color.Aqua;
            this.BtnSignup.Location = new System.Drawing.Point(318, 170);
            this.BtnSignup.Name = "BtnSignup";
            this.BtnSignup.Size = new System.Drawing.Size(75, 23);
            this.BtnSignup.TabIndex = 0;
            this.BtnSignup.Text = "SignUp";
            this.BtnSignup.UseVisualStyleBackColor = false;
            this.BtnSignup.Click += new System.EventHandler(this.BtnSignup_Click);
            this.BtnSignup.Validating += new System.ComponentModel.CancelEventHandler(this.BtnSignup_Validating);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(165, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "UserName";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(165, 129);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // txtpasswrd
            // 
            this.txtpasswrd.Location = new System.Drawing.Point(426, 122);
            this.txtpasswrd.Name = "txtpasswrd";
            this.txtpasswrd.Size = new System.Drawing.Size(100, 20);
            this.txtpasswrd.TabIndex = 3;
            this.txtpasswrd.Validating += new System.ComponentModel.CancelEventHandler(this.txtpasswrd_Validating);
            this.txtpasswrd.Validated += new System.EventHandler(this.txtpasswrd_Validated);
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(426, 24);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(100, 20);
            this.txtUsername.TabIndex = 4;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            this.txtUsername.Validating += new System.ComponentModel.CancelEventHandler(this.txtUsername_Validating);
            this.txtUsername.Validated += new System.EventHandler(this.txtUsername_Validated);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // btnclklogin
            // 
            this.btnclklogin.BackColor = System.Drawing.Color.Aqua;
            this.btnclklogin.Location = new System.Drawing.Point(274, 219);
            this.btnclklogin.Name = "btnclklogin";
            this.btnclklogin.Size = new System.Drawing.Size(175, 23);
            this.btnclklogin.TabIndex = 5;
            this.btnclklogin.Text = "Click here for Login";
            this.btnclklogin.UseVisualStyleBackColor = false;
            this.btnclklogin.Click += new System.EventHandler(this.btnclklogin_Click);
            // 
            // btnroleinsignup
            // 
            this.btnroleinsignup.BackColor = System.Drawing.Color.Aqua;
            this.btnroleinsignup.Location = new System.Drawing.Point(274, 264);
            this.btnroleinsignup.Name = "btnroleinsignup";
            this.btnroleinsignup.Size = new System.Drawing.Size(175, 31);
            this.btnroleinsignup.TabIndex = 11;
            this.btnroleinsignup.Text = "Click Here To Add Role";
            this.btnroleinsignup.UseVisualStyleBackColor = false;
            this.btnroleinsignup.Click += new System.EventHandler(this.btnroleinsignup_Click);
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 366);
            this.Controls.Add(this.btnroleinsignup);
            this.Controls.Add(this.btnclklogin);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtpasswrd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnSignup);
            this.Name = "SignUp";
            this.Text = "SignUp Form";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnSignup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpasswrd;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Button btnclklogin;
        private System.Windows.Forms.Button btnroleinsignup;
    }
}

