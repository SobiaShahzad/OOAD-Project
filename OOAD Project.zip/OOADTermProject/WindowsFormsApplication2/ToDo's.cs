﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class ToDo_s : Form
    {
        public ToDo_s()
        {
            InitializeComponent();
        }

        private void ToDo_s_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void addbtnintodo_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client sc = new ServiceReference1.Service1Client();
            ServiceReference1.ToDo t = new ServiceReference1.ToDo();
            t.NameOfToDo = todotasktxt.Text;
            //t.Date = tododateTimePicker.Text;
            sc.addToDo(t);
            MessageBox.Show("Role defined successfully");
            DataShow();
        }
        public void DataShow()
        {
            ServiceReference1.Service1Client c = new ServiceReference1.Service1Client();
            BindingSource bc = new BindingSource();
            bc.DataSource = c.getToDolist();
            todogridview.DataSource = bc;
        }

        private void clickheretogotoreportbtn_Click(object sender, EventArgs e)
        {
            ReportForm rf = new ReportForm();
            this.Close();
            rf.Show();
        }

        private void tododateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }

}
