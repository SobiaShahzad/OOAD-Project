﻿namespace WindowsFormsApplication2
{
    partial class Goals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanelingoal = new System.Windows.Forms.FlowLayoutPanel();
            this.rolebtningoal = new System.Windows.Forms.Button();
            this.goalbtningoal = new System.Windows.Forms.Button();
            this.todobtngoal = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.rolenamelblngoal = new System.Windows.Forms.Label();
            this.roletypelblingoal = new System.Windows.Forms.Label();
            this.rolenametxtingoal = new System.Windows.Forms.TextBox();
            this.goalcombobox = new System.Windows.Forms.ComboBox();
            this.goalgridview = new System.Windows.Forms.DataGridView();
            this.goallblingoal = new System.Windows.Forms.Label();
            this.goaltxtingoal = new System.Windows.Forms.TextBox();
            this.addgoalbtn = new System.Windows.Forms.Button();
            this.todobtningoal = new System.Windows.Forms.Button();
            this.flowLayoutPanelingoal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.goalgridview)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanelingoal
            // 
            this.flowLayoutPanelingoal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.flowLayoutPanelingoal.Controls.Add(this.rolebtningoal);
            this.flowLayoutPanelingoal.Controls.Add(this.goalbtningoal);
            this.flowLayoutPanelingoal.Controls.Add(this.todobtngoal);
            this.flowLayoutPanelingoal.Controls.Add(this.button1);
            this.flowLayoutPanelingoal.Location = new System.Drawing.Point(0, 12);
            this.flowLayoutPanelingoal.Name = "flowLayoutPanelingoal";
            this.flowLayoutPanelingoal.Size = new System.Drawing.Size(98, 135);
            this.flowLayoutPanelingoal.TabIndex = 0;
            // 
            // rolebtningoal
            // 
            this.rolebtningoal.BackColor = System.Drawing.SystemColors.Control;
            this.rolebtningoal.Location = new System.Drawing.Point(3, 3);
            this.rolebtningoal.Name = "rolebtningoal";
            this.rolebtningoal.Size = new System.Drawing.Size(75, 23);
            this.rolebtningoal.TabIndex = 8;
            this.rolebtningoal.Text = "Roles";
            this.rolebtningoal.UseVisualStyleBackColor = false;
            // 
            // goalbtningoal
            // 
            this.goalbtningoal.BackColor = System.Drawing.Color.Fuchsia;
            this.goalbtningoal.Location = new System.Drawing.Point(3, 32);
            this.goalbtningoal.Name = "goalbtningoal";
            this.goalbtningoal.Size = new System.Drawing.Size(75, 23);
            this.goalbtningoal.TabIndex = 9;
            this.goalbtningoal.Text = "Goals";
            this.goalbtningoal.UseVisualStyleBackColor = false;
            // 
            // todobtngoal
            // 
            this.todobtngoal.BackColor = System.Drawing.SystemColors.Control;
            this.todobtngoal.Location = new System.Drawing.Point(3, 61);
            this.todobtngoal.Name = "todobtngoal";
            this.todobtngoal.Size = new System.Drawing.Size(75, 23);
            this.todobtngoal.TabIndex = 10;
            this.todobtngoal.Text = "To Do\'s";
            this.todobtngoal.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.Location = new System.Drawing.Point(3, 90);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Goals";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(426, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Goals";
            // 
            // rolenamelblngoal
            // 
            this.rolenamelblngoal.AutoSize = true;
            this.rolenamelblngoal.Location = new System.Drawing.Point(294, 44);
            this.rolenamelblngoal.Name = "rolenamelblngoal";
            this.rolenamelblngoal.Size = new System.Drawing.Size(60, 13);
            this.rolenamelblngoal.TabIndex = 2;
            this.rolenamelblngoal.Text = "Role Name";
            // 
            // roletypelblingoal
            // 
            this.roletypelblingoal.AutoSize = true;
            this.roletypelblingoal.Location = new System.Drawing.Point(294, 86);
            this.roletypelblingoal.Name = "roletypelblingoal";
            this.roletypelblingoal.Size = new System.Drawing.Size(56, 13);
            this.roletypelblingoal.TabIndex = 3;
            this.roletypelblingoal.Text = "Role Type";
            // 
            // rolenametxtingoal
            // 
            this.rolenametxtingoal.Location = new System.Drawing.Point(402, 44);
            this.rolenametxtingoal.Name = "rolenametxtingoal";
            this.rolenametxtingoal.Size = new System.Drawing.Size(121, 20);
            this.rolenametxtingoal.TabIndex = 4;
            // 
            // goalcombobox
            // 
            this.goalcombobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.goalcombobox.FormattingEnabled = true;
            this.goalcombobox.Items.AddRange(new object[] {
            "Self",
            "Social",
            "Work",
            ""});
            this.goalcombobox.Location = new System.Drawing.Point(402, 83);
            this.goalcombobox.Name = "goalcombobox";
            this.goalcombobox.Size = new System.Drawing.Size(121, 21);
            this.goalcombobox.TabIndex = 5;
            // 
            // goalgridview
            // 
            this.goalgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.goalgridview.Location = new System.Drawing.Point(12, 165);
            this.goalgridview.Name = "goalgridview";
            this.goalgridview.Size = new System.Drawing.Size(805, 163);
            this.goalgridview.TabIndex = 6;
            this.goalgridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // goallblingoal
            // 
            this.goallblingoal.AutoSize = true;
            this.goallblingoal.Location = new System.Drawing.Point(294, 122);
            this.goallblingoal.Name = "goallblingoal";
            this.goallblingoal.Size = new System.Drawing.Size(35, 13);
            this.goallblingoal.TabIndex = 7;
            this.goallblingoal.Text = " Goal ";
            // 
            // goaltxtingoal
            // 
            this.goaltxtingoal.Location = new System.Drawing.Point(402, 122);
            this.goaltxtingoal.Name = "goaltxtingoal";
            this.goaltxtingoal.Size = new System.Drawing.Size(121, 20);
            this.goaltxtingoal.TabIndex = 8;
            // 
            // addgoalbtn
            // 
            this.addgoalbtn.BackColor = System.Drawing.SystemColors.Control;
            this.addgoalbtn.Location = new System.Drawing.Point(613, 44);
            this.addgoalbtn.Name = "addgoalbtn";
            this.addgoalbtn.Size = new System.Drawing.Size(75, 23);
            this.addgoalbtn.TabIndex = 9;
            this.addgoalbtn.Text = "Add Goal";
            this.addgoalbtn.UseVisualStyleBackColor = false;
            this.addgoalbtn.Click += new System.EventHandler(this.addgoalbtn_Click);
            // 
            // todobtningoal
            // 
            this.todobtningoal.BackColor = System.Drawing.SystemColors.Control;
            this.todobtningoal.Location = new System.Drawing.Point(613, 112);
            this.todobtningoal.Name = "todobtningoal";
            this.todobtningoal.Size = new System.Drawing.Size(75, 47);
            this.todobtningoal.TabIndex = 10;
            this.todobtningoal.Text = "Click here to go to TODO ";
            this.todobtningoal.UseVisualStyleBackColor = false;
            this.todobtningoal.Click += new System.EventHandler(this.todobtningoal_Click);
            // 
            // Goals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 340);
            this.Controls.Add(this.todobtningoal);
            this.Controls.Add(this.addgoalbtn);
            this.Controls.Add(this.goaltxtingoal);
            this.Controls.Add(this.goallblingoal);
            this.Controls.Add(this.goalgridview);
            this.Controls.Add(this.goalcombobox);
            this.Controls.Add(this.rolenametxtingoal);
            this.Controls.Add(this.roletypelblingoal);
            this.Controls.Add(this.rolenamelblngoal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.flowLayoutPanelingoal);
            this.Name = "Goals";
            this.Text = "Goals";
            this.Load += new System.EventHandler(this.Goals_Load);
            this.flowLayoutPanelingoal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.goalgridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelingoal;
        private System.Windows.Forms.Button rolebtningoal;
        private System.Windows.Forms.Button goalbtningoal;
        private System.Windows.Forms.Button todobtngoal;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label rolenamelblngoal;
        private System.Windows.Forms.Label roletypelblingoal;
        private System.Windows.Forms.TextBox rolenametxtingoal;
        private System.Windows.Forms.ComboBox goalcombobox;
        private System.Windows.Forms.DataGridView goalgridview;
        private System.Windows.Forms.Label goallblingoal;
        private System.Windows.Forms.TextBox goaltxtingoal;
        private System.Windows.Forms.Button addgoalbtn;
        private System.Windows.Forms.Button todobtningoal;
    }
}