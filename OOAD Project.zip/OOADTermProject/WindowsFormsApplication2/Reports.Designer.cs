﻿namespace WindowsFormsApplication2
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.reportsbtninreports = new System.Windows.Forms.Button();
            this.todobtninreports = new System.Windows.Forms.Button();
            this.goalbtninreports = new System.Windows.Forms.Button();
            this.rolebtninreports = new System.Windows.Forms.Button();
            this.tasklistbtninreport = new System.Windows.Forms.Button();
            this.balancebtninreports = new System.Windows.Forms.Button();
            this.datetimelbl = new System.Windows.Forms.Label();
            this.reportgridview = new System.Windows.Forms.DataGridView();
            this.addbtninreport = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.reportcomboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.reportgridview)).BeginInit();
            this.SuspendLayout();
            // 
            // reportsbtninreports
            // 
            this.reportsbtninreports.BackColor = System.Drawing.Color.Fuchsia;
            this.reportsbtninreports.Location = new System.Drawing.Point(25, 113);
            this.reportsbtninreports.Name = "reportsbtninreports";
            this.reportsbtninreports.Size = new System.Drawing.Size(75, 23);
            this.reportsbtninreports.TabIndex = 16;
            this.reportsbtninreports.Text = "Reports";
            this.reportsbtninreports.UseVisualStyleBackColor = false;
            // 
            // todobtninreports
            // 
            this.todobtninreports.Location = new System.Drawing.Point(25, 84);
            this.todobtninreports.Name = "todobtninreports";
            this.todobtninreports.Size = new System.Drawing.Size(75, 23);
            this.todobtninreports.TabIndex = 15;
            this.todobtninreports.Text = "To Do\'s";
            this.todobtninreports.UseVisualStyleBackColor = true;
            // 
            // goalbtninreports
            // 
            this.goalbtninreports.Location = new System.Drawing.Point(25, 55);
            this.goalbtninreports.Name = "goalbtninreports";
            this.goalbtninreports.Size = new System.Drawing.Size(75, 23);
            this.goalbtninreports.TabIndex = 14;
            this.goalbtninreports.Text = "Goals";
            this.goalbtninreports.UseVisualStyleBackColor = true;
            // 
            // rolebtninreports
            // 
            this.rolebtninreports.Location = new System.Drawing.Point(25, 26);
            this.rolebtninreports.Name = "rolebtninreports";
            this.rolebtninreports.Size = new System.Drawing.Size(75, 24);
            this.rolebtninreports.TabIndex = 13;
            this.rolebtninreports.Text = "Roles";
            this.rolebtninreports.UseVisualStyleBackColor = true;
            // 
            // tasklistbtninreport
            // 
            this.tasklistbtninreport.BackColor = System.Drawing.Color.Aqua;
            this.tasklistbtninreport.Location = new System.Drawing.Point(231, 40);
            this.tasklistbtninreport.Name = "tasklistbtninreport";
            this.tasklistbtninreport.Size = new System.Drawing.Size(75, 23);
            this.tasklistbtninreport.TabIndex = 17;
            this.tasklistbtninreport.Text = "Task List";
            this.tasklistbtninreport.UseVisualStyleBackColor = false;
            this.tasklistbtninreport.Click += new System.EventHandler(this.button1_Click);
            // 
            // balancebtninreports
            // 
            this.balancebtninreports.BackColor = System.Drawing.Color.Aqua;
            this.balancebtninreports.Location = new System.Drawing.Point(337, 40);
            this.balancebtninreports.Name = "balancebtninreports";
            this.balancebtninreports.Size = new System.Drawing.Size(75, 23);
            this.balancebtninreports.TabIndex = 18;
            this.balancebtninreports.Text = "Balance";
            this.balancebtninreports.UseVisualStyleBackColor = false;
            // 
            // datetimelbl
            // 
            this.datetimelbl.AutoSize = true;
            this.datetimelbl.Location = new System.Drawing.Point(228, 89);
            this.datetimelbl.Name = "datetimelbl";
            this.datetimelbl.Size = new System.Drawing.Size(77, 13);
            this.datetimelbl.TabIndex = 20;
            this.datetimelbl.Text = "Date and Time";
            // 
            // reportgridview
            // 
            this.reportgridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reportgridview.Location = new System.Drawing.Point(25, 142);
            this.reportgridview.Name = "reportgridview";
            this.reportgridview.Size = new System.Drawing.Size(555, 329);
            this.reportgridview.TabIndex = 21;
            this.reportgridview.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // addbtninreport
            // 
            this.addbtninreport.Location = new System.Drawing.Point(631, 170);
            this.addbtninreport.Name = "addbtninreport";
            this.addbtninreport.Size = new System.Drawing.Size(75, 23);
            this.addbtninreport.TabIndex = 23;
            this.addbtninreport.Text = "Add ";
            this.addbtninreport.UseVisualStyleBackColor = true;
            this.addbtninreport.Click += new System.EventHandler(this.addbtninreport_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(631, 212);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(312, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Reports";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // reportcomboBox
            // 
            this.reportcomboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.reportcomboBox.FormattingEnabled = true;
            this.reportcomboBox.Items.AddRange(new object[] {
            "Today",
            "Week",
            "Month",
            "Year"});
            this.reportcomboBox.Location = new System.Drawing.Point(337, 84);
            this.reportcomboBox.Name = "reportcomboBox";
            this.reportcomboBox.Size = new System.Drawing.Size(93, 21);
            this.reportcomboBox.TabIndex = 26;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 511);
            this.Controls.Add(this.reportcomboBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.addbtninreport);
            this.Controls.Add(this.reportgridview);
            this.Controls.Add(this.datetimelbl);
            this.Controls.Add(this.balancebtninreports);
            this.Controls.Add(this.tasklistbtninreport);
            this.Controls.Add(this.reportsbtninreports);
            this.Controls.Add(this.todobtninreports);
            this.Controls.Add(this.goalbtninreports);
            this.Controls.Add(this.rolebtninreports);
            this.Name = "ReportForm";
            this.Text = "Reports";
            this.Load += new System.EventHandler(this.ToDo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.reportgridview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button reportsbtninreports;
        private System.Windows.Forms.Button todobtninreports;
        private System.Windows.Forms.Button goalbtninreports;
        private System.Windows.Forms.Button rolebtninreports;
        private System.Windows.Forms.Button tasklistbtninreport;
        private System.Windows.Forms.Button balancebtninreports;
        private System.Windows.Forms.Label datetimelbl;
        private System.Windows.Forms.DataGridView reportgridview;
        private System.Windows.Forms.Button addbtninreport;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox reportcomboBox;
    }
}