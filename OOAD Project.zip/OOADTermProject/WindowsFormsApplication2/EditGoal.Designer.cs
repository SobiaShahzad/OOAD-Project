﻿namespace WindowsFormsApplication2
{
    partial class EditGoal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goallblinedit = new System.Windows.Forms.Label();
            this.goltxtinedit = new System.Windows.Forms.TextBox();
            this.savegoalbtninedit = new System.Windows.Forms.Button();
            this.roletypelblinedit = new System.Windows.Forms.Label();
            this.roletypecomboboxineditgoal = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // goallblinedit
            // 
            this.goallblinedit.AutoSize = true;
            this.goallblinedit.Location = new System.Drawing.Point(193, 47);
            this.goallblinedit.Name = "goallblinedit";
            this.goallblinedit.Size = new System.Drawing.Size(29, 13);
            this.goallblinedit.TabIndex = 0;
            this.goallblinedit.Text = "Goal";
            // 
            // goltxtinedit
            // 
            this.goltxtinedit.Location = new System.Drawing.Point(287, 40);
            this.goltxtinedit.Name = "goltxtinedit";
            this.goltxtinedit.Size = new System.Drawing.Size(100, 20);
            this.goltxtinedit.TabIndex = 1;
            // 
            // savegoalbtninedit
            // 
            this.savegoalbtninedit.Location = new System.Drawing.Point(246, 185);
            this.savegoalbtninedit.Name = "savegoalbtninedit";
            this.savegoalbtninedit.Size = new System.Drawing.Size(75, 23);
            this.savegoalbtninedit.TabIndex = 2;
            this.savegoalbtninedit.Text = "Save Goal";
            this.savegoalbtninedit.UseVisualStyleBackColor = true;
            // 
            // roletypelblinedit
            // 
            this.roletypelblinedit.AutoSize = true;
            this.roletypelblinedit.Location = new System.Drawing.Point(193, 102);
            this.roletypelblinedit.Name = "roletypelblinedit";
            this.roletypelblinedit.Size = new System.Drawing.Size(56, 13);
            this.roletypelblinedit.TabIndex = 3;
            this.roletypelblinedit.Text = "Role Type";
            // 
            // roletypecomboboxineditgoal
            // 
            this.roletypecomboboxineditgoal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.roletypecomboboxineditgoal.FormattingEnabled = true;
            this.roletypecomboboxineditgoal.Items.AddRange(new object[] {
            "Social",
            "Self",
            "Work"});
            this.roletypecomboboxineditgoal.Location = new System.Drawing.Point(287, 94);
            this.roletypecomboboxineditgoal.Name = "roletypecomboboxineditgoal";
            this.roletypecomboboxineditgoal.Size = new System.Drawing.Size(100, 21);
            this.roletypecomboboxineditgoal.TabIndex = 4;
            // 
            // EditGoal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 304);
            this.Controls.Add(this.roletypecomboboxineditgoal);
            this.Controls.Add(this.roletypelblinedit);
            this.Controls.Add(this.savegoalbtninedit);
            this.Controls.Add(this.goltxtinedit);
            this.Controls.Add(this.goallblinedit);
            this.Name = "EditGoal";
            this.Text = "EditGoal";
            this.Load += new System.EventHandler(this.EditGoal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label goallblinedit;
        private System.Windows.Forms.TextBox goltxtinedit;
        private System.Windows.Forms.Button savegoalbtninedit;
        private System.Windows.Forms.Label roletypelblinedit;
        private System.Windows.Forms.ComboBox roletypecomboboxineditgoal;
    }
}