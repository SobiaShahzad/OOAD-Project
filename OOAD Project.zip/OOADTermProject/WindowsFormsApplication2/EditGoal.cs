﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class EditGoal : Form
    {

        private ServiceReference1.Roles editrols = new ServiceReference1.Roles();
        private ServiceReference1.Service1Client Server = new ServiceReference1.Service1Client();
        int index;
        public EditGoal()
        {
            InitializeComponent();
        }

        public EditGoal(ServiceReference1.Roles rol,int Index)
        {
            editrols = rol;
            index = Index;
            InitializeComponent();
        }


        private void EditGoal_Load(object sender, EventArgs e)
        {

        }
    }
}
