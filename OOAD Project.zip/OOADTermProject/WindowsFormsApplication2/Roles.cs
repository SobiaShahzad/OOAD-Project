﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Roles : Form
    {
        public Roles()
        {
            InitializeComponent();
            BindMethod();
        }
        public void BindMethod()
        {
            // Making the button of edit 
            DataGridViewButtonColumn editbutton = new DataGridViewButtonColumn();
            editbutton.FlatStyle = FlatStyle.Popup;
            editbutton.HeaderText = "Edit";
            editbutton.Name = "Edit";
            editbutton.UseColumnTextForButtonValue = true;
            editbutton.Text = "Edit";
            editbutton.Width = 50;
            if (rolegridview.Columns.Contains(editbutton.Name = "Edit"))
            {

            }
            else
            {
                rolegridview.Columns.Add(editbutton);
            }

            // Making the button of Delete
            DataGridViewButtonColumn deletebutton = new DataGridViewButtonColumn();
            deletebutton.FlatStyle = FlatStyle.Popup;
            deletebutton.HeaderText = "Delete";
            deletebutton.Name = "Delete";
            deletebutton.UseColumnTextForButtonValue = true;
            deletebutton.Text = "Delete";
            deletebutton.Width = 50;
            if (rolegridview.Columns.Contains(deletebutton.Name = "Delete"))
            {

            }
            else
            {
                rolegridview.Columns.Add(deletebutton);
            }

            // Making the button of AddGoals
            DataGridViewButtonColumn addGoalbutton = new DataGridViewButtonColumn();
            addGoalbutton.FlatStyle = FlatStyle.Popup;
            addGoalbutton.HeaderText = "Delete";
            addGoalbutton.Name = "Delete";
            addGoalbutton.UseColumnTextForButtonValue = true;
            addGoalbutton.Text = "Delete";
            addGoalbutton.Width = 50;
            if (rolegridview.Columns.Contains(addGoalbutton.Name = "Delete"))
            {

            }
            else
            {
                rolegridview.Columns.Add(addGoalbutton);
            }


        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void addrolebtm_Click(object sender, EventArgs e)
        {

            ServiceReference1.Service1Client s = new ServiceReference1.Service1Client();
            ServiceReference1.Roles r = new ServiceReference1.Roles();
            r.RoleName = rolenametxt.Text;
            r.RoleType = roletypecombobox.Text;
            s.addRole(r);
            MessageBox.Show("Role defined successfully");
            Datashow();
        }

        public void Datashow()
        {
            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
            BindingSource b = new BindingSource();
            b.DataSource = client.getroleList();
            rolegridview.DataSource = b;
        }

        private void rolenametxt_Validating(object sender, CancelEventArgs e)
        {

        }

        private void Roles_Load(object sender, EventArgs e)
        {
            Datashow();
        }

        private void rolegridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.ColumnIndex==0)
            {
                ServiceReference1.Service1Client ss = new ServiceReference1.Service1Client();
                ServiceReference1.Roles rl = new ServiceReference1.Roles();
                int i=e.RowIndex;   // i for index
                rl = ss.getRoles(i);
                EditGoal edit = new EditGoal(rl, i);
                edit.Show();
                //MessageBox.Show("Editted succesfully");


            }
            else if(e.ColumnIndex==1)
            {
                ServiceReference1.Service1Client ss = new ServiceReference1.Service1Client();
                ServiceReference1.Roles rl = new ServiceReference1.Roles();
                int i = e.RowIndex;   
                ss.DeleteRole(i);
                Datashow();
                MessageBox.Show("Deleted successfullY!");
            }
            else if(e.ColumnIndex==2)
            {
                DataGridViewRow row = this.rolegridview.Rows[e.RowIndex];
                ServiceReference1.Service1Client sr = new ServiceReference1.Service1Client();
                ServiceReference1.Roles rs = new ServiceReference1.Roles();
                int INDEX = e.RowIndex;
                 rs = sr.getRoles(INDEX);
               // rs = sr.addGoal(INDEX);
                Goals go = new Goals(rs, INDEX);
                go.Show();
                MessageBox.Show("Goal Added successfuly!");

            }
            
        }

        private void goalbtninrole_Click(object sender, EventArgs e)
        {
            Goals gs = new Goals();
            this.Close();
            gs.Show();
        }
    }
}
