﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void BtnSignup_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.UserDetail NewUser = new ServiceReference1.UserDetail();
            NewUser.UserName1 = txtUsername.Text;
            NewUser.Password1 = txtpasswrd.Text;
            server.AddUser(NewUser);
            MessageBox.Show("SignUp SUCCESFULLY");
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtUsername_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtUsername, null);
        }

        private void txtUsername_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtUsername, "Enter UserName");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtUsername, null);
            }
        }

        private void txtpasswrd_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtpasswrd.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(txtpasswrd, "Enter UserName");
            }
            else
            {
                e.Cancel = false;
                errorProvider1.SetError(txtpasswrd, null);
            }
        }

        private void txtpasswrd_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtpasswrd, null);
        }

        private void BtnSignup_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btnclklogin_Click(object sender, EventArgs e)
        {
            Login login =new  Login();
            login.Show();
        }

        private void btnroleinsignup_Click(object sender, EventArgs e)
        {
            Roles rolelinkwithsignUp = new Roles();
            rolelinkwithsignUp.Show();        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
